import React from 'react'

const BookingContext = React.createContext({
  bookingList: [],
 
})

export default BookingContext